# Metal Price App (Web)

## Run
npm install
npm run dev

Then open http://localhost:19006