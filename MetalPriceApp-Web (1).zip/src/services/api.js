import axios from "axios";

const API_KEY = "goldapi-dnkmsmjymskz4-io";

export const fetchMetalPrice = async (metal) => {
  const response = await axios.get(
    `https://www.goldapi.io/api/${metal}/INR`,
    {
      headers: {
        "x-access-token": API_KEY,
        "Content-Type": "application/json"
      }
    }
  );
  return response.data;
};