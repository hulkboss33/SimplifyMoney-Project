import { View, Text, ActivityIndicator, TouchableOpacity } from "react-native";

export default function MetalTile({ metal, data, loading, error, onPress }) {
  return (
    <TouchableOpacity onPress={onPress} style={{ padding: 15, backgroundColor: "#eee", margin: 10, borderRadius: 8 }}>
      <Text style={{ fontSize: 18, fontWeight: "bold" }}>{metal.name}</Text>
      {loading && <ActivityIndicator />}
      {error && <Text style={{ color: "red" }}>Failed to load</Text>}
      {data && <Text>24K Price: ₹ {data.price_gram_24k}</Text>}
    </TouchableOpacity>
  );
}