import { View, Text } from "react-native";

export default function DetailScreen({ route }) {
  const { metal, data } = route.params;

  return (
    <View style={{ padding: 20 }}>
      <Text style={{ fontSize: 22, fontWeight: "bold" }}>{metal.name} Details</Text>
      <Text>Price (24K/gram): ₹ {data.price_gram_24k}</Text>
      <Text>Open: ₹ {data.open_price}</Text>
      <Text>Prev Close: ₹ {data.prev_close_price}</Text>
    </View>
  );
}