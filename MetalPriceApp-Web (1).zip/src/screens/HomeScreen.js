import { ScrollView } from "react-native";
import { useEffect, useState } from "react";
import MetalTile from "../components/MetalTile";
import { METALS } from "../utils/constants";
import { fetchMetalPrice } from "../services/api";

export default function HomeScreen({ navigation }) {
  const [prices, setPrices] = useState({});
  const [loading, setLoading] = useState({});
  const [error, setError] = useState({});

  useEffect(() => {
    let mounted = true;

    const load = async () => {
      for (const metal of METALS) {
        if (!mounted) return;
        await loadPrice(metal);
        await new Promise(res => setTimeout(res, 2000));
      }
    };

    load();
    return () => { mounted = false; };
  }, []);

  const loadPrice = async (metal) => {
    setLoading(prev => ({ ...prev, [metal.code]: true }));
    try {
      const data = await fetchMetalPrice(metal.code);
      setPrices(prev => ({ ...prev, [metal.code]: data }));
      setError(prev => ({ ...prev, [metal.code]: false }));
    } catch {
      setError(prev => ({ ...prev, [metal.code]: true }));
    } finally {
      setLoading(prev => ({ ...prev, [metal.code]: false }));
    }
  };

  return (
    <ScrollView>
      {METALS.map(metal => (
        <MetalTile
          key={metal.code}
          metal={metal}
          data={prices[metal.code]}
          loading={loading[metal.code]}
          error={error[metal.code]}
          onPress={() => prices[metal.code] && navigation.navigate("Details", {
            metal,
            data: prices[metal.code]
          })}
        />
      ))}
    </ScrollView>
  );
}