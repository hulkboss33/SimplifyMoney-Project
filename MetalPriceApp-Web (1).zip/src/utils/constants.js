export const METALS = [
  { name: "Gold", code: "XAU" }
];